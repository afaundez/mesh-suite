#include "src/lib/refinement/headers/Constant.h"
namespace Constant{
    char *preProcessNames[] = { "Ninguno", "Arreglar Aristas Involucradas"};

    char *triangleSelectionNames[]={"No Priorizar", "Menor &Aacute;ngulo interno", "Menor Tama&ntilde;o Arista","Menor Tama&ntilde;o, Priridad Bordes", "Menor Circumradio"};

    char *newPointNames[]={ "Lepp-Bisecci&oacute;n","Ruppert","Lepp-Delaunay", "Lepp-Centroid", "Ungor", "Lepp-Ruppert" };

    char *insertionNames[] = { "Inserci&oacute;n B&aacute;sica", "Inserci&oacute;n Intercambio Diagonales", "Inserci&oacute;n Cavidad"};
}
