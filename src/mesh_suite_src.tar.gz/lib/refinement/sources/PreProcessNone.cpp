#include "src/lib/refinement/headers/PreProcessNone.h"

PreProcessNone::PreProcessNone(): PreProcess(){

}

void PreProcessNone::execute(){
    //qDebug("none");
}

PreProcessNone::~PreProcessNone(){

}
